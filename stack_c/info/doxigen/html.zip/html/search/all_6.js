var searchData=
[
  ['test43_5f42',['Test43_42',['../tests_8cpp.html#a493ef3151f86304ba8b029ecd4f182a6',1,'Test43_42(Stack *stack):&#160;tests.cpp'],['../tests_8h.html#a493ef3151f86304ba8b029ecd4f182a6',1,'Test43_42(Stack *stack):&#160;tests.cpp']]],
  ['testpushandpoplarge',['TestPushAndPopLarge',['../tests_8cpp.html#af81b3e5901fbd73cbb0b7a3ed7704e51',1,'TestPushAndPopLarge(Stack *stack):&#160;tests.cpp'],['../tests_8h.html#af81b3e5901fbd73cbb0b7a3ed7704e51',1,'TestPushAndPopLarge(Stack *stack):&#160;tests.cpp']]],
  ['testpushpop10',['TestPushPop10',['../tests_8cpp.html#a32759c0f06fdeae9ffeb7371bdd2661f',1,'TestPushPop10(Stack *stack, int elem_to_push):&#160;tests.cpp'],['../tests_8h.html#a32759c0f06fdeae9ffeb7371bdd2661f',1,'TestPushPop10(Stack *stack, int elem_to_push):&#160;tests.cpp']]],
  ['tests_2ecpp',['tests.cpp',['../tests_8cpp.html',1,'']]],
  ['tests_2eh',['tests.h',['../tests_8h.html',1,'']]],
  ['testtestdump',['TestTestDump',['../tests_8cpp.html#aa9e48237f5e9e2e7f2379e72032a2195',1,'TestTestDump(Stack *stack):&#160;tests.cpp'],['../tests_8h.html#aa9e48237f5e9e2e7f2379e72032a2195',1,'TestTestDump(Stack *stack):&#160;tests.cpp']]],
  ['testtrygetlast',['TestTryGetLast',['../tests_8cpp.html#ac7a82f8f1be1561e3a02765f176c3dc6',1,'TestTryGetLast(Stack *stack):&#160;tests.cpp'],['../tests_8h.html#ac7a82f8f1be1561e3a02765f176c3dc6',1,'TestTryGetLast(Stack *stack):&#160;tests.cpp']]],
  ['testtrypopempty',['TestTryPopEmpty',['../tests_8cpp.html#a2a1c0b9e5ed521fc87c522375bc335d1',1,'TestTryPopEmpty(Stack *stack):&#160;tests.cpp'],['../tests_8h.html#a2a1c0b9e5ed521fc87c522375bc335d1',1,'TestTryPopEmpty(Stack *stack):&#160;tests.cpp']]]
];
