var searchData=
[
  ['capacity',['capacity',['../struct_stack.html#afb6d4ad9d2904c20d50102d310c963e0',1,'Stack']]]
];
