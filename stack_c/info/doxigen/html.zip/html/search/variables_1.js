var searchData=
[
  ['data',['data',['../struct_stack.html#a3106563f8f21938dc9c387399b0cfdae',1,'Stack']]]
];
