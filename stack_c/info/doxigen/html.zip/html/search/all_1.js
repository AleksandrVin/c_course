var searchData=
[
  ['data',['data',['../struct_stack.html#a3106563f8f21938dc9c387399b0cfdae',1,'Stack']]],
  ['data_5fstack',['data_stack',['../_stack_8h.html#aa2cf87122fee408b240b07ad7bef95df',1,'Stack.h']]]
];
