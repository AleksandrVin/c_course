var searchData=
[
  ['mem_5fprotect_5fbegin',['mem_protect_begin',['../struct_stack.html#ac216ba09ad9045cd83cd53ebb7648878',1,'Stack']]],
  ['mem_5fprotect_5fend',['mem_protect_end',['../struct_stack.html#a164f303220955b7684a291265d5dc2f3',1,'Stack']]],
  ['mem_5fshop',['MEM_SHOP',['../_stack_8h.html#a31bfd944dc6e6d6ff19a750356b8d187',1,'Stack.h']]]
];
