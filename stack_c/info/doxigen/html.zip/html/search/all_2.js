var searchData=
[
  ['error_5flog',['ERROR_LOG',['../_stack_8h.html#a9653db1cb65b94c9d98d35834ded328c',1,'Stack.h']]]
];
