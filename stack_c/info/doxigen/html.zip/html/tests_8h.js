var tests_8h =
[
    [ "Test43_42", "tests_8h.html#a493ef3151f86304ba8b029ecd4f182a6", null ],
    [ "TestPushAndPopLarge", "tests_8h.html#af81b3e5901fbd73cbb0b7a3ed7704e51", null ],
    [ "TestPushPop10", "tests_8h.html#a32759c0f06fdeae9ffeb7371bdd2661f", null ],
    [ "TestTestDump", "tests_8h.html#aa9e48237f5e9e2e7f2379e72032a2195", null ],
    [ "TestTryGetLast", "tests_8h.html#ac7a82f8f1be1561e3a02765f176c3dc6", null ],
    [ "TestTryPopEmpty", "tests_8h.html#a2a1c0b9e5ed521fc87c522375bc335d1", null ]
];