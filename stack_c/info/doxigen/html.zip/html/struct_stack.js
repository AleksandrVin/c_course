var struct_stack =
[
    [ "capacity", "struct_stack.html#afb6d4ad9d2904c20d50102d310c963e0", null ],
    [ "data", "struct_stack.html#a3106563f8f21938dc9c387399b0cfdae", null ],
    [ "mem_protect_begin", "struct_stack.html#ac216ba09ad9045cd83cd53ebb7648878", null ],
    [ "mem_protect_end", "struct_stack.html#a164f303220955b7684a291265d5dc2f3", null ],
    [ "size", "struct_stack.html#a3a469595caaaf49bbce059efabbe07b5", null ],
    [ "stack_state", "struct_stack.html#a8fc766bd6109dab0df21ffcb360f26fd", null ]
];