var _stack_8cpp =
[
    [ "StackCalcResize", "_stack_8cpp.html#a9a00ad97477e59c359d0410a46233653", null ],
    [ "StackClean", "_stack_8cpp.html#a28154d65cb96e76c8be4b0be929e24db", null ],
    [ "StackCtor", "_stack_8cpp.html#a9248cbfe64c1998fecdf7af6dbcda025", null ],
    [ "StackCtorDin", "_stack_8cpp.html#a1ddc101354b602c49875faa17ac89283", null ],
    [ "StackDtor", "_stack_8cpp.html#af090c504a5436c2a041a389725de484b", null ],
    [ "StackDtorDin", "_stack_8cpp.html#a1685bf189e540fbc8d9aa420c6243aac", null ],
    [ "StackDump", "_stack_8cpp.html#a1cdbbb67775515ee1de887ea46d6a5eb", null ],
    [ "StackFree", "_stack_8cpp.html#a3eac8d89e697e5151d10ee1ba1915290", null ],
    [ "StackFront", "_stack_8cpp.html#aa2468daaa4e13529892e5bda273abf2c", null ],
    [ "StackOk", "_stack_8cpp.html#ab9316611fbaf334168ffd8de2bbdb4b4", null ],
    [ "StackPop", "_stack_8cpp.html#ab9ab3bcbe1af5140cc1a3cac9087e42a", null ],
    [ "StackPush", "_stack_8cpp.html#a42cc66765aeb8c0528421a393af6bcc0", null ],
    [ "StackRealloc", "_stack_8cpp.html#a20160e6dbc38f9e26cfb0f840e757f5d", null ],
    [ "StackResize", "_stack_8cpp.html#a3e970b031bdeeeeb8b0b537fb02bef26", null ],
    [ "StackSrink_to_fit", "_stack_8cpp.html#ad67c7c911cc1d1824dbfd2054252b960", null ]
];