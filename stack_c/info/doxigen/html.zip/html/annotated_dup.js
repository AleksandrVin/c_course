var annotated_dup =
[
    [ "Stack", "struct_stack.html", "struct_stack" ]
];